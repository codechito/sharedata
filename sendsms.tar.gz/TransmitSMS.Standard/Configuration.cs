namespace TransmitSMS.Standard
{
    public partial class Configuration
    {


        //The base Uri for API calls
        public static string BaseUri = "https://api.transmitsms.com";

        //Obtain your API Key by logging into BurstSMS and visiting the settings page
        //TODO: Replace the Apikey with an appropriate value
        public static string Apikey = "APIKEY";

        //Obtain your API Secret by logging into BurstSMS and visiting the settings page
        //TODO: Replace the Apisecret with an appropriate value
        public static string Apisecret = "APISECRET";

    }
}