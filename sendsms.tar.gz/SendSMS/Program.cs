﻿using System;
using TransmitSMS.Standard;

namespace TransmitsmsProj
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");


            Configuration.Apikey = "fea0bbfa3a56e339809585cc2d6aaa78";
            Configuration.Apisecret = "testing123";
            Configuration.BaseUri = "http://api.reseller.burst.dev.local";

            string message = "Test 12345";
            string format = "json";
            string to = "61423093477";

            TransmitSMSClient client = new TransmitSMSClient();

            try
            {
                dynamic result = client.SMS.SendSMS(format, message, to);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
